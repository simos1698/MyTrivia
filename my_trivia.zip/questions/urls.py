from django.urls import path
from . import views
from django_registration.backends.one_step.views import RegistrationView

urlpatterns = [
    path('questions/', views.questions, name='questions'),
    path('questions/<int:id>', views.question_profile, name="question_profile")
]