from django.http import HttpResponse
from django.template import loader
from .models import Question

def questions(request):
    template = loader.get_template('questions.html')
    myquestions = Question.objects.all().values()

    context = {'myquestions': myquestions}

    return HttpResponse(template.render(context, request))

def question_profile(request, id):
    template = loader.get_template('question_profile.html')

    question = Question.objects.get(id=id)
    context = {'question' : question}

    return HttpResponse(template.render(context, request))
