from re import template
from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Question

def main(request):
    template = loader.get_template('main.html')
    return HttpResponse(template.render({}, request))

def users(request):
    template = loader.get_template('users.html')
    myusers = User.objects.all().values()

    context = {'myusers': myusers}

    return HttpResponse(template.render(context, request))

def register(request):
    form = UserCreationForm()
    context = {form}
    return HttpResponse(template.render(context, request))
